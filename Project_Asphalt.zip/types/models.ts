export type User = {
  id: string;
  email: string;
  createdAt: string;
};

export type TransportProfile = {
  id: string;
  name: string;
  kind: "SCOOTER" | "CAR" | "BIKE" | "OTHER";
  kmRate: number;
  isActive: boolean;
};

export type UserSettings = {
  timezone: string;
  currency: string;
  electricityPricePerKwh: number;
  carKmPerLitre: number;
  scooterKwhPerKm: number;
};

export type Trip = {
  id: string;
  profileId: string;
  tripDate: string;
  description: string;
  distanceKm: number;
  fuelPricePerLitre: number;
  earningsAmount: number;
  electricityCost: number;
  equivalentFuelLitres: number;
  equivalentFuelCost: number;
  netProfit: number;
};

export type DashboardKPI = {
  totalProfit: number;
  totalElectricityCost: number;
  totalEquivalentFuelCost: number;
  totalDistance: number;
  totalCostSavedVsCar: number;
};

export type PeriodAggregate = {
  bucket: string;
  profit: number;
  electricityCost: number;
  equivalentFuelCost: number;
  costSavedVsCar: number;
  distanceKm: number;
};
