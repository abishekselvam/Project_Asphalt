# Project Asphalt

Segway doesn't let you track and visualize the savings of using their scooter over using the car, so this is an open-source option to do that.

Mobile-first SaaS-style web app to log e-scooter trips and track profit, electricity cost, and fuel savings vs car baseline.

## Stack

- Next.js 15 (App Router) + TypeScript
- PostgreSQL + Prisma
- NextAuth credentials auth (email/password)
- React Hook Form + Zod
- Recharts dashboard visuals
- Docker + Docker Compose

## Features

- Full account registration/login
- Per-user data isolation
- Trip CRUD with auto-filled latest fuel price
- Configurable settings:
  - Car mileage (km/litre)
  - Electricity price (per kWh)
  - Scooter efficiency (kWh/km)
  - Currency + timezone
- Multiple transport profiles (scooter/car/bike/other)
- Daily/weekly/monthly KPI dashboard:
  - Profit
  - Electricity cost
  - Equivalent fuel cost avoided
  - Distance
  - Cost saved vs car

## Local Run (without Docker)

1. Install dependencies:
   ```bash
   npm install
   ```
2. Create env file:
   ```bash
   cp .env.example .env
   ```
3. Push schema:
   ```bash
   npx prisma db push
   ```
4. Run app:
   ```bash
   npm run dev
   ```

## Docker Run

1. Create env file:
   ```bash
   cat > .env <<'EOF2'
   DATABASE_URL=postgresql://asphalt:asphalt@db:5432/asphalt?schema=public
   NEXTAUTH_URL=http://localhost:3000
   NEXTAUTH_SECRET=asphalt_dev_secret_change_me_please_2026
   EOF2
   ```
2. Start services:
   ```bash
   docker compose up --build
   ```
3. Open app:
   - [http://localhost:3000](http://localhost:3000)

## API Summary

- `POST /api/auth/register`
- `GET|PUT /api/settings`
- `GET|POST /api/profiles`
- `PATCH|DELETE /api/profiles/:id`
- `GET|POST /api/trips`
- `PATCH|DELETE /api/trips/:id`
- `GET /api/dashboard?range=daily|weekly|monthly&from=...&to=...`
- `GET /api/health`

## Tests

```bash
npm run test
```

Covers:
- Calculation engine correctness and edge cases
- Aggregation correctness for dashboard summaries
