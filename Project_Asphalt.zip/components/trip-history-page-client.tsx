"use client";

import { useEffect, useMemo, useState } from "react";
import { currency } from "@/lib/format";
import type { Trip, UserSettings } from "@/types/models";

export default function TripHistoryPageClient() {
  const [trips, setTrips] = useState<Trip[]>([]);
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [msg, setMsg] = useState("");

  const money = useMemo(() => (value: number) => currency(value, settings?.currency ?? "AUD"), [settings?.currency]);

  async function load() {
    const [tRes, sRes] = await Promise.all([fetch("/api/trips"), fetch("/api/settings")]);
    if (!tRes.ok || !sRes.ok) {
      setMsg("Failed to load trips.");
      return;
    }
    const tJson = (await tRes.json()) as { trips: Trip[] };
    const sJson = (await sRes.json()) as UserSettings;
    setTrips(tJson.trips);
    setSettings(sJson);
  }

  useEffect(() => {
    load().catch(() => setMsg("Failed to load trips."));
  }, []);

  async function deleteTrip(id: string) {
    const res = await fetch(`/api/trips/${id}`, { method: "DELETE" });
    if (!res.ok) {
      setMsg("Could not delete trip.");
      return;
    }
    await load();
  }

  return (
    <section className="glass rounded-2xl p-4">
      {msg && <p className="mb-3 text-sm text-[var(--accent-coral)]">{msg}</p>}
      <div className="overflow-x-auto">
        <table className="w-full min-w-[720px] text-sm">
          <thead>
            <tr className="text-left text-[var(--text-muted)]">
              <th className="py-2">Date</th>
              <th>Description</th>
              <th>Km</th>
              <th>Electricity</th>
              <th>Fuel Avoided</th>
              <th>Profit</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {trips.map((trip) => (
              <tr key={trip.id} className="border-t border-white/10">
                <td className="py-2">{new Date(trip.tripDate).toLocaleDateString()}</td>
                <td>{trip.description}</td>
                <td>{trip.distanceKm.toFixed(1)}</td>
                <td>{money(trip.electricityCost)}</td>
                <td>{money(trip.equivalentFuelCost)}</td>
                <td className={trip.netProfit >= 0 ? "text-[var(--accent-green)]" : "text-[var(--accent-coral)]"}>
                  {money(trip.netProfit)}
                </td>
                <td>
                  <button onClick={() => deleteTrip(trip.id)} className="text-[var(--accent-coral)]">
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </section>
  );
}
