"use client";

import { useEffect, useMemo, useState } from "react";
import { useForm } from "react-hook-form";
import { signOut } from "next-auth/react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";
import { KpiCard } from "@/components/kpi-card";
import type { DashboardKPI, PeriodAggregate, TransportProfile, Trip, UserSettings } from "@/types/models";
import { currency } from "@/lib/format";

type Props = {
  email: string;
};

type TripFormInput = {
  profileId: string;
  tripDate: string;
  description: string;
  distanceKm?: number;
  fuelPricePerLitre?: number;
};

type ProfileFormInput = {
  name: string;
  kind: "SCOOTER" | "CAR" | "BIKE" | "OTHER";
  kmRate?: number;
};

type SettingsFormInput = {
  timezone: string;
  currency: string;
  electricityPricePerKwh?: number;
  carKmPerLitre?: number;
  scooterKwhPerKm?: number;
};

const toDateInput = (iso?: string) => {
  const date = iso ? new Date(iso) : new Date();
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};

export default function DashboardClient({ email }: Props) {
  const [profiles, setProfiles] = useState<TransportProfile[]>([]);
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [trips, setTrips] = useState<Trip[]>([]);
  const [kpi, setKpi] = useState<DashboardKPI | null>(null);
  const [series, setSeries] = useState<PeriodAggregate[]>([]);
  const [range, setRange] = useState<"daily" | "weekly" | "monthly">("weekly");
  const [latestFuelPrice, setLatestFuelPrice] = useState<number>(1.9);
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string>("");

  const tripForm = useForm<TripFormInput>({
    defaultValues: {
      profileId: "",
      tripDate: toDateInput(),
      description: "",
      distanceKm: undefined,
      fuelPricePerLitre: undefined
    }
  });

  const profileForm = useForm<ProfileFormInput>({
    defaultValues: { name: "", kind: "OTHER", kmRate: undefined }
  });

  const settingsForm = useForm<SettingsFormInput>({
    defaultValues: {
      timezone: "Australia/Melbourne",
      currency: "AUD",
      electricityPricePerKwh: undefined,
      carKmPerLitre: undefined,
      scooterKwhPerKm: undefined
    }
  });

  async function loadBase() {
    const [pRes, sRes, tRes] = await Promise.all([
      fetch("/api/profiles"),
      fetch("/api/settings"),
      fetch("/api/trips")
    ]);

    if (!pRes.ok || !sRes.ok || !tRes.ok) {
      throw new Error("Failed to load data");
    }

    const pJson = (await pRes.json()) as TransportProfile[];
    const sJson = (await sRes.json()) as UserSettings;
    const tJson = (await tRes.json()) as { trips: Trip[]; latestFuelPrice: number | null };

    setProfiles(pJson);
    setSettings(sJson);
    setTrips(tJson.trips);
    setLatestFuelPrice(tJson.latestFuelPrice ?? latestFuelPrice);

    settingsForm.reset(sJson);
    tripForm.setValue("profileId", pJson[0]?.id ?? "");
    tripForm.setValue("fuelPricePerLitre", tJson.latestFuelPrice ?? latestFuelPrice);
  }

  async function loadDashboard(nextRange = range) {
    const res = await fetch(`/api/dashboard?range=${nextRange}`);
    if (!res.ok) throw new Error("Failed to load dashboard");
    const json = (await res.json()) as { kpi: DashboardKPI; series: PeriodAggregate[] };
    setKpi(json.kpi);
    setSeries(json.series);
  }

  async function refreshAll(nextRange = range) {
    setBusy(true);
    try {
      await Promise.all([loadBase(), loadDashboard(nextRange)]);
      setMsg("");
    } catch {
      setMsg("Failed to load data. Please refresh.");
    } finally {
      setBusy(false);
    }
  }

  useEffect(() => {
    refreshAll();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  useEffect(() => {
    loadDashboard(range).catch(() => setMsg("Failed to load dashboard."));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [range]);

  const money = useMemo(() => (value: number) => currency(value, settings?.currency ?? "AUD"), [settings?.currency]);

  async function createTrip(values: TripFormInput) {
    const payload = {
      ...values,
      tripDate: new Date(values.tripDate).toISOString(),
      distanceKm: Number(values.distanceKm ?? 0),
      fuelPricePerLitre: Number(values.fuelPricePerLitre ?? latestFuelPrice)
    };

    const res = await fetch("/api/trips", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    if (!res.ok) {
      setMsg("Could not save trip.");
      return;
    }

    tripForm.reset({
      profileId: values.profileId,
      tripDate: toDateInput(),
      description: "",
      distanceKm: undefined,
      fuelPricePerLitre: payload.fuelPricePerLitre
    });

    setLatestFuelPrice(payload.fuelPricePerLitre);
    await refreshAll();
  }

  async function deleteTrip(id: string) {
    const res = await fetch(`/api/trips/${id}`, { method: "DELETE" });
    if (!res.ok) {
      setMsg("Could not delete trip.");
      return;
    }
    await refreshAll();
  }

  async function createProfile(values: ProfileFormInput) {
    const res = await fetch("/api/profiles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...values, kmRate: Number(values.kmRate ?? 0) })
    });
    if (!res.ok) {
      setMsg("Could not create profile.");
      return;
    }
    profileForm.reset({ name: "", kind: "OTHER", kmRate: undefined });
    await refreshAll();
  }

  async function saveSettings(values: SettingsFormInput) {
    const payload = {
      ...values,
      currency: values.currency.toUpperCase(),
      electricityPricePerKwh: Number(values.electricityPricePerKwh ?? 0),
      carKmPerLitre: Number(values.carKmPerLitre ?? 0),
      scooterKwhPerKm: Number(values.scooterKwhPerKm ?? 0)
    };

    const res = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      setMsg("Could not save settings.");
      return;
    }
    setSettings((await res.json()) as UserSettings);
    setMsg("Settings updated.");
    await loadDashboard(range);
  }

  return (
    <main className="mx-auto w-full max-w-7xl px-4 pb-28 pt-6 md:px-6">
      <header className="animate-fade-up mb-5 flex items-center justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">Asphalt Profit Tracker</h1>
          <p className="text-sm text-[var(--text-muted)]">{email}</p>
        </div>
        <button
          className="rounded-xl border border-white/15 px-3 py-2 text-sm"
          onClick={() => signOut({ callbackUrl: "/login" })}
        >
          Sign out
        </button>
      </header>

      <div className="mb-4 flex gap-3 overflow-x-auto pb-2">
        {[
          { id: "daily", label: "Daily" },
          { id: "weekly", label: "Weekly" },
          { id: "monthly", label: "Monthly" }
        ].map((option) => (
          <button
            key={option.id}
            className={`shrink-0 rounded-xl px-4 py-2 text-sm ${
              range === option.id
                ? "bg-[var(--accent-cyan)] text-black"
                : "glass border border-white/10 text-[var(--text-muted)]"
            }`}
            onClick={() => setRange(option.id as "daily" | "weekly" | "monthly")}
          >
            {option.label}
          </button>
        ))}
      </div>

      {msg && <p className="mb-4 text-sm text-[var(--accent-coral)]">{msg}</p>}

      <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <KpiCard label="Electricity" value={kpi?.totalElectricityCost ?? 0} formatter={money} accent="coral" />
        <KpiCard label="Fuel Cost Avoided" value={kpi?.totalEquivalentFuelCost ?? 0} formatter={money} />
        <KpiCard label="Profit" value={kpi?.totalCostSavedVsCar ?? 0} formatter={money} accent="green" />
        <KpiCard
          label="E-KMs"
          value={kpi?.totalDistance ?? 0}
          formatter={(v) => `${v.toFixed(1)} km`}
          accent="cyan"
        />
      </section>

      <section className="glass animate-fade-up mt-5 rounded-2xl p-4">
        <h2 className="text-lg font-semibold">E-KMs vs Normal Car Travel</h2>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div className="rounded-xl border border-white/10 bg-black/20 p-3">
            <p className="text-xs uppercase tracking-[0.12em] text-[var(--text-muted)]">E-Scooter Distance</p>
            <p className="mt-1 text-xl font-semibold text-[var(--accent-cyan)]">{(kpi?.totalDistance ?? 0).toFixed(1)} km</p>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/20 p-3">
            <p className="text-xs uppercase tracking-[0.12em] text-[var(--text-muted)]">Equivalent Car Travel</p>
            <p className="mt-1 text-xl font-semibold text-[var(--accent-green)]">{(kpi?.totalDistance ?? 0).toFixed(1)} km</p>
          </div>
        </div>
      </section>

      <section className="glass animate-fade-up mt-5 rounded-2xl p-4">
        <h2 className="mb-3 text-lg font-semibold">Performance Trend</h2>
        <div className="h-72 w-full">
          <ResponsiveContainer>
            <AreaChart data={series}>
              <defs>
                <linearGradient id="profitFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2ce59b" stopOpacity={0.7} />
                  <stop offset="95%" stopColor="#2ce59b" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#234" opacity={0.35} />
              <XAxis dataKey="bucket" stroke="#9bb1c8" tick={{ fontSize: 12 }} />
              <YAxis stroke="#9bb1c8" tick={{ fontSize: 12 }} />
              <Tooltip
                contentStyle={{
                  background: "#0e1622",
                  border: "1px solid rgba(255,255,255,0.15)",
                  borderRadius: 12
                }}
              />
              <Legend />
              <Area type="monotone" dataKey="profit" stroke="#2ce59b" fill="url(#profitFill)" name="Profit (Fuel Saved)" />
              <Area type="monotone" dataKey="equivalentFuelCost" stroke="#56c9ff" fillOpacity={0} name="Fuel Avoided" />
              <Area type="monotone" dataKey="electricityCost" stroke="#ff7f66" fillOpacity={0} name="Electricity" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>

      <section className="mt-5 grid gap-5 md:grid-cols-2">
        <form onSubmit={tripForm.handleSubmit(createTrip)} className="glass animate-fade-up rounded-2xl p-4">
          <h3 className="text-lg font-semibold">Log Trip</h3>
          <div className="mt-3 grid gap-3">
            <label className="text-sm">Transport Profile</label>
            <select {...tripForm.register("profileId", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2">
              {profiles.map((profile) => (
                <option key={profile.id} value={profile.id}>
                  {profile.name}
                </option>
              ))}
            </select>

            <label className="text-sm">Trip Date & Time</label>
            <input type="datetime-local" {...tripForm.register("tripDate", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />

            <label className="text-sm">Trip Description (ex. Morning commute)</label>
            <input {...tripForm.register("description", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" placeholder="Morning commute" />

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm">Distance Travelled (ex. 10)</label>
                <input type="number" step="0.01" placeholder="10" {...tripForm.register("distanceKm", { valueAsNumber: true, required: true })} className="mt-1 w-full rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
              </div>
              <div>
                <label className="text-sm">Fuel Price per Litre (ex. 1.95)</label>
                <input type="number" step="0.01" placeholder="1.95" {...tripForm.register("fuelPricePerLitre", { valueAsNumber: true, required: true })} className="mt-1 w-full rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
              </div>
            </div>
          </div>

          <button disabled={busy} className="mt-4 w-full rounded-xl bg-[var(--accent-green)] px-4 py-2 font-semibold text-black disabled:opacity-50">
            Save trip
          </button>
          <p className="mt-2 text-xs text-[var(--text-muted)]">Fuel price auto-fills from your latest trip: {latestFuelPrice.toFixed(2)}</p>
        </form>

        <div className="space-y-5">
          <form onSubmit={profileForm.handleSubmit(createProfile)} className="glass animate-fade-up rounded-2xl p-4">
            <h3 className="text-lg font-semibold">Transport Profiles</h3>
            <div className="mt-3 grid gap-3">
              <input placeholder="Profile Name (ex. Weekend Delivery Car)" {...profileForm.register("name", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
              <div className="grid grid-cols-2 gap-3">
                <select {...profileForm.register("kind", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2">
                  <option value="SCOOTER">SCOOTER</option>
                  <option value="CAR">CAR</option>
                  <option value="BIKE">BIKE</option>
                  <option value="OTHER">OTHER</option>
                </select>
                <input type="number" step="0.00001" placeholder="Rate per KM (ex. 0.00001)" {...profileForm.register("kmRate", { valueAsNumber: true, required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
              </div>
            </div>
            <button className="mt-4 w-full rounded-xl border border-[var(--accent-cyan)] px-4 py-2 text-[var(--accent-cyan)]">Add profile</button>

            <div className="mt-4 space-y-2">
              {profiles.map((profile) => (
                <div key={profile.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-black/20 px-3 py-2 text-sm">
                  <span>{profile.name} ({profile.kind})</span>
                  <span className="text-[var(--text-muted)]">{profile.kmRate.toFixed(5)}/km</span>
                </div>
              ))}
            </div>
          </form>

          <form onSubmit={settingsForm.handleSubmit(saveSettings)} className="glass animate-fade-up rounded-2xl p-4">
            <h3 className="text-lg font-semibold">Cost Settings</h3>
            <div className="mt-3 grid gap-3">
              <input placeholder="Timezone (ex. Australia/Melbourne)" {...settingsForm.register("timezone", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
              <input placeholder="Currency (ex. AUD)" maxLength={3} {...settingsForm.register("currency", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2 uppercase" />
              <input type="number" step="0.0001" placeholder="Electricity Price per kWh (ex. 0.2500)" {...settingsForm.register("electricityPricePerKwh", { valueAsNumber: true, required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
              <input type="number" step="0.01" placeholder="Car KM per Litre (ex. 14)" {...settingsForm.register("carKmPerLitre", { valueAsNumber: true, required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
              <input type="number" step="0.0001" placeholder="Scooter kWh per KM (ex. 0.0300)" {...settingsForm.register("scooterKwhPerKm", { valueAsNumber: true, required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
            </div>
            <button className="mt-4 w-full rounded-xl border border-[var(--accent-green)] px-4 py-2 text-[var(--accent-green)]">Save settings</button>
          </form>
        </div>
      </section>

      <section className="glass animate-fade-up mt-5 rounded-2xl p-4">
        <h3 className="text-lg font-semibold">Trip History</h3>
        <div className="mt-3 overflow-x-auto">
          <table className="w-full min-w-[720px] text-sm">
            <thead>
              <tr className="text-left text-[var(--text-muted)]">
                <th className="py-2">Date</th>
                <th>Description</th>
                <th>Km</th>
                <th>Electricity</th>
                <th>Fuel Avoided</th>
                <th>Profit (Fuel Saved)</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {trips.map((trip) => (
                <tr key={trip.id} className="border-t border-white/10">
                  <td className="py-2">{new Date(trip.tripDate).toLocaleDateString()}</td>
                  <td>{trip.description}</td>
                  <td>{trip.distanceKm.toFixed(1)}</td>
                  <td>{money(trip.electricityCost)}</td>
                  <td>{money(trip.equivalentFuelCost)}</td>
                  <td className={trip.netProfit >= 0 ? "text-[var(--accent-green)]" : "text-[var(--accent-coral)]"}>
                    {money(trip.netProfit)}
                  </td>
                  <td>
                    <button onClick={() => deleteTrip(trip.id)} className="text-[var(--accent-coral)]">
                      Delete
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      <button
        className="fixed bottom-6 right-4 rounded-full bg-[var(--accent-green)] px-5 py-3 font-semibold text-black shadow-lg md:hidden"
        onClick={() => window.scrollTo({ top: 420, behavior: "smooth" })}
      >
        + Quick Add Trip
      </button>
    </main>
  );
}
