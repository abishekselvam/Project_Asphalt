"use client";

import { useEffect, useState } from "react";

type Props = {
  value: number;
  format: (value: number) => string;
  durationMs?: number;
};

export function AnimatedNumber({ value, format, durationMs = 450 }: Props) {
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    const start = display;
    const delta = value - start;
    const startedAt = performance.now();

    const tick = (time: number) => {
      const progress = Math.min(1, (time - startedAt) / durationMs);
      setDisplay(start + delta * progress);
      if (progress < 1) requestAnimationFrame(tick);
    };

    requestAnimationFrame(tick);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [value]);

  return <span className="kpi-value">{format(display)}</span>;
}
