"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import type { TransportProfile, UserSettings } from "@/types/models";

type ProfileFormInput = {
  name: string;
  kind: "SCOOTER" | "CAR" | "BIKE" | "OTHER";
  kmRate?: number;
};

type SettingsFormInput = {
  timezone: string;
  currency: string;
  electricityPricePerKwh?: number;
  carKmPerLitre?: number;
  scooterKwhPerKm?: number;
};

export default function SettingsPageClient() {
  const [profiles, setProfiles] = useState<TransportProfile[]>([]);
  const [msg, setMsg] = useState("");

  const profileForm = useForm<ProfileFormInput>({
    defaultValues: { name: "", kind: "OTHER", kmRate: undefined }
  });

  const settingsForm = useForm<SettingsFormInput>({
    defaultValues: {
      timezone: "Australia/Melbourne",
      currency: "AUD",
      electricityPricePerKwh: undefined,
      carKmPerLitre: undefined,
      scooterKwhPerKm: undefined
    }
  });

  async function load() {
    const [pRes, sRes] = await Promise.all([fetch("/api/profiles"), fetch("/api/settings")]);
    if (!pRes.ok || !sRes.ok) {
      setMsg("Failed to load settings.");
      return;
    }
    const pJson = (await pRes.json()) as TransportProfile[];
    const sJson = (await sRes.json()) as UserSettings;
    setProfiles(pJson);
    settingsForm.reset(sJson);
  }

  useEffect(() => {
    load().catch(() => setMsg("Failed to load settings."));
  }, []);

  async function createProfile(values: ProfileFormInput) {
    const res = await fetch("/api/profiles", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ ...values, kmRate: Number(values.kmRate ?? 0) })
    });
    if (!res.ok) {
      setMsg("Could not create profile.");
      return;
    }
    setMsg("Profile added.");
    profileForm.reset({ name: "", kind: "OTHER", kmRate: undefined });
    await load();
  }

  async function deleteProfile(id: string) {
    const res = await fetch(`/api/profiles/${id}`, { method: "DELETE" });
    if (!res.ok) {
      setMsg("Could not delete profile.");
      return;
    }
    setMsg("Profile deleted or archived.");
    await load();
  }

  async function saveSettings(values: SettingsFormInput) {
    const payload = {
      ...values,
      currency: values.currency.toUpperCase(),
      electricityPricePerKwh: Number(values.electricityPricePerKwh ?? 0),
      carKmPerLitre: Number(values.carKmPerLitre ?? 0),
      scooterKwhPerKm: Number(values.scooterKwhPerKm ?? 0)
    };

    const res = await fetch("/api/settings", {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });
    if (!res.ok) {
      setMsg("Could not save settings.");
      return;
    }

    setMsg("Settings updated.");
    await load();
  }

  return (
    <div className="grid gap-5 md:grid-cols-2">
      <form onSubmit={profileForm.handleSubmit(createProfile)} className="glass rounded-2xl p-4">
        <h3 className="text-lg font-semibold">Transport Profiles</h3>
        <div className="mt-3 grid gap-3">
          <input placeholder="Profile Name (ex. Weekend Delivery Car)" {...profileForm.register("name", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
          <div className="grid grid-cols-2 gap-3">
            <select {...profileForm.register("kind", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2">
              <option value="SCOOTER">SCOOTER</option>
              <option value="CAR">CAR</option>
              <option value="BIKE">BIKE</option>
              <option value="OTHER">OTHER</option>
            </select>
            <input type="number" step="0.00001" placeholder="Rate per KM (ex. 0.00001)" {...profileForm.register("kmRate", { valueAsNumber: true, required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
          </div>
        </div>
        <button className="mt-4 w-full rounded-xl border border-[var(--accent-cyan)] px-4 py-2 text-[var(--accent-cyan)]">Add profile</button>

        <div className="mt-4 space-y-2">
          {profiles.map((profile) => (
            <div key={profile.id} className="flex items-center justify-between rounded-xl border border-white/10 bg-black/20 px-3 py-2 text-sm">
              <span>{profile.name} ({profile.kind})</span>
              <div className="flex items-center gap-3">
                <span className="text-[var(--text-muted)]">{profile.kmRate.toFixed(5)}/km</span>
                <button type="button" onClick={() => deleteProfile(profile.id)} className="text-[var(--accent-coral)]">
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      </form>

      <form onSubmit={settingsForm.handleSubmit(saveSettings)} className="glass rounded-2xl p-4">
        <h3 className="text-lg font-semibold">Cost Settings</h3>
        <div className="mt-3 grid gap-3">
          <input placeholder="Timezone (ex. Australia/Melbourne)" {...settingsForm.register("timezone", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
          <input placeholder="Currency (ex. AUD)" maxLength={3} {...settingsForm.register("currency", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2 uppercase" />
          <input type="number" step="0.0001" placeholder="Electricity Price per kWh (ex. 0.2500)" {...settingsForm.register("electricityPricePerKwh", { valueAsNumber: true, required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
          <input type="number" step="0.01" placeholder="Car KM per Litre (ex. 14)" {...settingsForm.register("carKmPerLitre", { valueAsNumber: true, required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
          <input type="number" step="0.0001" placeholder="Scooter kWh per KM (ex. 0.0300)" {...settingsForm.register("scooterKwhPerKm", { valueAsNumber: true, required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
        </div>
        <button className="mt-4 w-full rounded-xl border border-[var(--accent-green)] px-4 py-2 text-[var(--accent-green)]">Save settings</button>
      </form>

      {msg && <p className="text-sm text-[var(--accent-cyan)] md:col-span-2">{msg}</p>}
    </div>
  );
}
