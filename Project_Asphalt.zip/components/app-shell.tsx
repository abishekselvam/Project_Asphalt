"use client";

import Link from "next/link";
import { signOut } from "next-auth/react";
import { usePathname } from "next/navigation";

const links = [
  { href: "/dashboard", label: "Dashboard" },
  { href: "/log-trip", label: "Log Trip" },
  { href: "/trip-history", label: "Trip History" }
] as const;

export function AppShell({
  email,
  title,
  children
}: {
  email: string;
  title: string;
  children: React.ReactNode;
}) {
  const pathname = usePathname();

  return (
    <main className="mx-auto w-full max-w-7xl px-4 pb-28 pt-6 md:px-6">
      <header className="animate-fade-up mb-5 flex items-start justify-between gap-4">
        <div>
          <h1 className="text-3xl font-semibold">Asphalt Profit Tracker</h1>
          <p className="text-sm text-[var(--text-muted)]">{email}</p>
        </div>
        <button
          className="rounded-xl border border-white/15 px-3 py-2 text-sm"
          onClick={() => signOut({ callbackUrl: "/login" })}
        >
          Sign out
        </button>
      </header>

      <nav className="mb-5 flex items-center gap-2 overflow-x-auto pb-2">
        {links.map((link) => (
          <Link
            key={link.href}
            href={link.href}
            className={`shrink-0 rounded-xl px-4 py-2 text-sm ${
              pathname === link.href
                ? "bg-[var(--accent-cyan)] text-black"
                : "glass border border-white/10 text-[var(--text-muted)]"
            }`}
          >
            {link.label}
          </Link>
        ))}
        <Link
          href="/settings"
          aria-label="Settings"
          title="Settings"
          className={`ml-auto inline-flex h-10 w-10 items-center justify-center rounded-xl ${
            pathname === "/settings"
              ? "bg-[var(--accent-cyan)] text-black"
              : "glass border border-white/10 text-[var(--text-muted)]"
          }`}
        >
          <svg viewBox="0 0 24 24" className="h-5 w-5" fill="none" stroke="currentColor" strokeWidth="2">
            <circle cx="12" cy="12" r="3" />
            <path d="M19.4 15a1.7 1.7 0 0 0 .34 1.87l.06.06a2 2 0 1 1-2.83 2.83l-.06-.06A1.7 1.7 0 0 0 15 19.4a1.7 1.7 0 0 0-1 .6 1.7 1.7 0 0 0-.4 1.06V21a2 2 0 1 1-4 0v-.09A1.7 1.7 0 0 0 8.99 19.4a1.7 1.7 0 0 0-1.87.34l-.06.06a2 2 0 1 1-2.83-2.83l.06-.06A1.7 1.7 0 0 0 4.6 15a1.7 1.7 0 0 0-.6-1 1.7 1.7 0 0 0-1.06-.4H2.9a2 2 0 1 1 0-4h.09A1.7 1.7 0 0 0 4.6 8.99a1.7 1.7 0 0 0-.34-1.87l-.06-.06a2 2 0 1 1 2.83-2.83l.06.06A1.7 1.7 0 0 0 8.99 4.6c.39 0 .76-.14 1.04-.4.27-.28.43-.65.43-1.04V3a2 2 0 1 1 4 0v.09c0 .39.15.76.43 1.04.28.26.65.4 1.04.4a1.7 1.7 0 0 0 1-.4l.06-.06a2 2 0 1 1 2.83 2.83l-.06.06A1.7 1.7 0 0 0 19.4 8.99c0 .39.14.76.4 1.04.28.27.65.43 1.04.43H21a2 2 0 1 1 0 4h-.09a1.7 1.7 0 0 0-1.04.43c-.26.28-.4.65-.4 1.04Z" />
          </svg>
        </Link>
      </nav>

      <section className="animate-fade-up">
        <h2 className="mb-4 text-xl font-semibold">{title}</h2>
        {children}
      </section>
    </main>
  );
}
