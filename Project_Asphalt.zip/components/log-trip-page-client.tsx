"use client";

import { useEffect, useState } from "react";
import { useForm } from "react-hook-form";
import type { TransportProfile } from "@/types/models";

type TripFormInput = {
  profileId: string;
  tripDate: string;
  description: string;
  distanceKm?: number;
  fuelPricePerLitre?: number;
};

const toDateInput = () => {
  const date = new Date();
  return new Date(date.getTime() - date.getTimezoneOffset() * 60000).toISOString().slice(0, 16);
};

export default function LogTripPageClient() {
  const [profiles, setProfiles] = useState<TransportProfile[]>([]);
  const [latestFuelPrice, setLatestFuelPrice] = useState<number>(1.9);
  const [message, setMessage] = useState<string>("");
  const [busy, setBusy] = useState(false);

  const tripForm = useForm<TripFormInput>({
    defaultValues: {
      profileId: "",
      tripDate: toDateInput(),
      description: "",
      distanceKm: undefined,
      fuelPricePerLitre: undefined
    }
  });

  useEffect(() => {
    Promise.all([fetch("/api/profiles"), fetch("/api/trips")])
      .then(async ([pRes, tRes]) => {
        const pJson = (await pRes.json()) as TransportProfile[];
        const tJson = (await tRes.json()) as { latestFuelPrice: number | null };
        setProfiles(pJson);
        if (pJson[0]) tripForm.setValue("profileId", pJson[0].id);
        const price = tJson.latestFuelPrice ?? 1.9;
        setLatestFuelPrice(price);
        tripForm.setValue("fuelPricePerLitre", price);
      })
      .catch(() => setMessage("Failed to load form data."));
  }, [tripForm]);

  async function createTrip(values: TripFormInput) {
    setBusy(true);
    setMessage("");
    const payload = {
      ...values,
      tripDate: new Date(values.tripDate).toISOString(),
      distanceKm: Number(values.distanceKm ?? 0),
      fuelPricePerLitre: Number(values.fuelPricePerLitre ?? latestFuelPrice)
    };

    const res = await fetch("/api/trips", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(payload)
    });

    setBusy(false);
    if (!res.ok) {
      setMessage("Could not save trip.");
      return;
    }

    setMessage("Trip logged.");
    tripForm.reset({
      profileId: values.profileId,
      tripDate: toDateInput(),
      description: "",
      distanceKm: undefined,
      fuelPricePerLitre: payload.fuelPricePerLitre
    });
    setLatestFuelPrice(payload.fuelPricePerLitre);
  }

  return (
    <form onSubmit={tripForm.handleSubmit(createTrip)} className="glass rounded-2xl p-4 md:max-w-2xl">
      <h3 className="text-lg font-semibold">Log Trip</h3>
      <div className="mt-3 grid gap-3">
        <label className="text-sm">Transport Profile</label>
        <select {...tripForm.register("profileId", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2">
          {profiles.map((profile) => (
            <option key={profile.id} value={profile.id}>
              {profile.name}
            </option>
          ))}
        </select>

        <label className="text-sm">Trip Date & Time</label>
        <input type="datetime-local" {...tripForm.register("tripDate", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" />

        <label className="text-sm">Trip Description (ex. Morning commute)</label>
        <input {...tripForm.register("description", { required: true })} className="rounded-xl border border-white/15 bg-black/20 px-3 py-2" placeholder="Morning commute" />

        <div className="grid grid-cols-2 gap-3">
          <div>
            <label className="text-sm">Distance Travelled (ex. 10)</label>
            <input type="number" step="0.01" placeholder="10" {...tripForm.register("distanceKm", { valueAsNumber: true, required: true })} className="mt-1 w-full rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
          </div>
          <div>
            <label className="text-sm">Fuel Price per Litre (ex. 1.95)</label>
            <input type="number" step="0.01" placeholder="1.95" {...tripForm.register("fuelPricePerLitre", { valueAsNumber: true, required: true })} className="mt-1 w-full rounded-xl border border-white/15 bg-black/20 px-3 py-2" />
          </div>
        </div>
      </div>

      <button disabled={busy} className="mt-4 w-full rounded-xl bg-[var(--accent-green)] px-4 py-2 font-semibold text-black disabled:opacity-50">
        Save trip
      </button>
      <p className="mt-2 text-xs text-[var(--text-muted)]">Fuel price auto-fills from your latest trip: {latestFuelPrice.toFixed(2)}</p>
      {message && <p className="mt-2 text-sm text-[var(--accent-cyan)]">{message}</p>}
    </form>
  );
}
