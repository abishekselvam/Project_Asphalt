"use client";

import { useEffect, useMemo, useState } from "react";
import {
  Area,
  AreaChart,
  CartesianGrid,
  Legend,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis
} from "recharts";
import { KpiCard } from "@/components/kpi-card";
import { currency } from "@/lib/format";
import type { DashboardKPI, PeriodAggregate, UserSettings } from "@/types/models";

export default function DashboardOverview() {
  const [kpi, setKpi] = useState<DashboardKPI | null>(null);
  const [series, setSeries] = useState<PeriodAggregate[]>([]);
  const [settings, setSettings] = useState<UserSettings | null>(null);
  const [range, setRange] = useState<"daily" | "weekly" | "monthly">("weekly");

  useEffect(() => {
    Promise.all([fetch("/api/dashboard?range=weekly"), fetch("/api/settings")])
      .then(async ([dRes, sRes]) => {
        const dJson = (await dRes.json()) as { kpi: DashboardKPI; series: PeriodAggregate[] };
        const sJson = (await sRes.json()) as UserSettings;
        setKpi(dJson.kpi);
        setSeries(dJson.series);
        setSettings(sJson);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    fetch(`/api/dashboard?range=${range}`)
      .then((res) => res.json())
      .then((json: { kpi: DashboardKPI; series: PeriodAggregate[] }) => {
        setKpi(json.kpi);
        setSeries(json.series);
      })
      .catch(() => {});
  }, [range]);

  const money = useMemo(() => (value: number) => currency(value, settings?.currency ?? "AUD"), [settings?.currency]);

  return (
    <>
      <div className="mb-4 flex gap-3 overflow-x-auto pb-2">
        {[
          { id: "daily", label: "Daily" },
          { id: "weekly", label: "Weekly" },
          { id: "monthly", label: "Monthly" }
        ].map((option) => (
          <button
            key={option.id}
            className={`shrink-0 rounded-xl px-4 py-2 text-sm ${
              range === option.id
                ? "bg-[var(--accent-cyan)] text-black"
                : "glass border border-white/10 text-[var(--text-muted)]"
            }`}
            onClick={() => setRange(option.id as "daily" | "weekly" | "monthly")}
          >
            {option.label}
          </button>
        ))}
      </div>

      <section className="grid grid-cols-2 gap-3 md:grid-cols-4">
        <KpiCard label="Electricity" value={kpi?.totalElectricityCost ?? 0} formatter={money} accent="coral" />
        <KpiCard label="Fuel Cost Avoided" value={kpi?.totalEquivalentFuelCost ?? 0} formatter={money} />
        <KpiCard label="Profit" value={kpi?.totalCostSavedVsCar ?? 0} formatter={money} accent="green" />
        <KpiCard label="E-KMs" value={kpi?.totalDistance ?? 0} formatter={(v) => `${v.toFixed(1)} km`} accent="cyan" />
      </section>

      <section className="glass mt-5 rounded-2xl p-4">
        <h2 className="text-lg font-semibold">E-KMs vs Normal Car Travel</h2>
        <div className="mt-3 grid grid-cols-2 gap-3">
          <div className="rounded-xl border border-white/10 bg-black/20 p-3">
            <p className="text-xs uppercase tracking-[0.12em] text-[var(--text-muted)]">E-Scooter Distance</p>
            <p className="mt-1 text-xl font-semibold text-[var(--accent-cyan)]">{(kpi?.totalDistance ?? 0).toFixed(1)} km</p>
          </div>
          <div className="rounded-xl border border-white/10 bg-black/20 p-3">
            <p className="text-xs uppercase tracking-[0.12em] text-[var(--text-muted)]">Equivalent Car Travel</p>
            <p className="mt-1 text-xl font-semibold text-[var(--accent-green)]">{(kpi?.totalDistance ?? 0).toFixed(1)} km</p>
          </div>
        </div>
      </section>

      <section className="glass mt-5 rounded-2xl p-4">
        <h2 className="mb-3 text-lg font-semibold">Performance Trend</h2>
        <div className="h-72 w-full">
          <ResponsiveContainer>
            <AreaChart data={series}>
              <defs>
                <linearGradient id="profitFill" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="5%" stopColor="#2ce59b" stopOpacity={0.7} />
                  <stop offset="95%" stopColor="#2ce59b" stopOpacity={0} />
                </linearGradient>
              </defs>
              <CartesianGrid strokeDasharray="3 3" stroke="#234" opacity={0.35} />
              <XAxis dataKey="bucket" stroke="#9bb1c8" tick={{ fontSize: 12 }} />
              <YAxis stroke="#9bb1c8" tick={{ fontSize: 12 }} />
              <Tooltip
                contentStyle={{
                  background: "#0e1622",
                  border: "1px solid rgba(255,255,255,0.15)",
                  borderRadius: 12
                }}
              />
              <Legend />
              <Area type="monotone" dataKey="profit" stroke="#2ce59b" fill="url(#profitFill)" name="Profit" />
              <Area type="monotone" dataKey="equivalentFuelCost" stroke="#56c9ff" fillOpacity={0} name="Fuel Avoided" />
              <Area type="monotone" dataKey="electricityCost" stroke="#ff7f66" fillOpacity={0} name="Electricity" />
            </AreaChart>
          </ResponsiveContainer>
        </div>
      </section>
    </>
  );
}
