import { AnimatedNumber } from "@/components/animated-number";

type Props = {
  label: string;
  value: number;
  formatter: (v: number) => string;
  accent?: "green" | "coral" | "cyan";
};

export function KpiCard({ label, value, formatter, accent = "cyan" }: Props) {
  const accentClass =
    accent === "green"
      ? "text-[var(--accent-green)]"
      : accent === "coral"
        ? "text-[var(--accent-coral)]"
        : "text-[var(--accent-cyan)]";

  return (
    <div className="glass animate-fade-up rounded-2xl p-4">
      <p className="text-xs uppercase tracking-[0.16em] text-[var(--text-muted)]">{label}</p>
      <p className={`mt-2 text-2xl font-semibold ${accentClass}`}>
        <AnimatedNumber value={value} format={formatter} />
      </p>
    </div>
  );
}
