export type CalcInput = {
  distanceKm: number;
  fuelPricePerLitre: number;
  carKmPerLitre: number;
  electricityPricePerKwh: number;
  scooterKwhPerKm: number;
};

export type CalcResult = {
  equivalentFuelLitres: number;
  equivalentFuelCost: number;
  electricityCost: number;
  netProfit: number;
  costSavedVsCar: number;
};

const round = (value: number, dp = 4) => Number(value.toFixed(dp));

export function calculateTripMetrics(input: CalcInput): CalcResult {
  const equivalentFuelLitres = input.carKmPerLitre === 0 ? 0 : input.distanceKm / input.carKmPerLitre;
  const equivalentFuelCost = equivalentFuelLitres * input.fuelPricePerLitre;
  const electricityCost = input.distanceKm * input.scooterKwhPerKm * input.electricityPricePerKwh;
  const costSavedVsCar = equivalentFuelCost - electricityCost;
  const netProfit = costSavedVsCar;

  return {
    equivalentFuelLitres: round(equivalentFuelLitres),
    equivalentFuelCost: round(equivalentFuelCost),
    electricityCost: round(electricityCost),
    netProfit: round(netProfit),
    costSavedVsCar: round(costSavedVsCar)
  };
}
