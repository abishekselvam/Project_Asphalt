export type TripLike = {
  tripDate: Date;
  netProfit: number;
  electricityCost: number;
  equivalentFuelCost: number;
  distanceKm: number;
};

export type Range = "daily" | "weekly" | "monthly";

export function bucketKey(date: Date, range: Range) {
  const year = date.getUTCFullYear();
  const month = String(date.getUTCMonth() + 1).padStart(2, "0");
  const day = String(date.getUTCDate()).padStart(2, "0");

  if (range === "monthly") return `${year}-${month}`;
  if (range === "weekly") {
    const target = new Date(Date.UTC(year, date.getUTCMonth(), date.getUTCDate()));
    const weekday = target.getUTCDay() || 7;
    target.setUTCDate(target.getUTCDate() + 4 - weekday);
    const y = target.getUTCFullYear();
    const firstJan = new Date(Date.UTC(y, 0, 1));
    const week = Math.ceil((((target.getTime() - firstJan.getTime()) / 86400000) + 1) / 7);
    return `${y}-W${String(week).padStart(2, "0")}`;
  }
  return `${year}-${month}-${day}`;
}

export function aggregateTrips(trips: TripLike[], range: Range) {
  const kpi = {
    totalProfit: 0,
    totalElectricityCost: 0,
    totalEquivalentFuelCost: 0,
    totalDistance: 0,
    totalCostSavedVsCar: 0
  };

  const byBucket = new Map<
    string,
    { bucket: string; profit: number; electricityCost: number; equivalentFuelCost: number; costSavedVsCar: number; distanceKm: number }
  >();

  for (const trip of trips) {
    const costSavedVsCar = trip.equivalentFuelCost - trip.electricityCost;

    kpi.totalProfit += trip.netProfit;
    kpi.totalElectricityCost += trip.electricityCost;
    kpi.totalEquivalentFuelCost += trip.equivalentFuelCost;
    kpi.totalDistance += trip.distanceKm;
    kpi.totalCostSavedVsCar += costSavedVsCar;

    const bucket = bucketKey(trip.tripDate, range);
    const row = byBucket.get(bucket) || {
      bucket,
      profit: 0,
      electricityCost: 0,
      equivalentFuelCost: 0,
      costSavedVsCar: 0,
      distanceKm: 0
    };

    row.profit += trip.netProfit;
    row.electricityCost += trip.electricityCost;
    row.equivalentFuelCost += trip.equivalentFuelCost;
    row.costSavedVsCar += costSavedVsCar;
    row.distanceKm += trip.distanceKm;

    byBucket.set(bucket, row);
  }

  const round = (value: number) => Number(value.toFixed(4));

  return {
    kpi: Object.fromEntries(Object.entries(kpi).map(([key, value]) => [key, round(value)])),
    series: Array.from(byBucket.values()).map((item) => ({
      ...item,
      profit: round(item.profit),
      electricityCost: round(item.electricityCost),
      equivalentFuelCost: round(item.equivalentFuelCost),
      costSavedVsCar: round(item.costSavedVsCar),
      distanceKm: round(item.distanceKm)
    }))
  };
}
