import { Trip, TransportProfile, UserSettings } from "@/types/models";

type DecimalLike = { toNumber(): number };

const n = (value: DecimalLike) => value.toNumber();

export function serializeSettings(settings: {
  timezone: string;
  currency: string;
  electricityPricePerKwh: DecimalLike;
  carKmPerLitre: DecimalLike;
  scooterKwhPerKm: DecimalLike;
}): UserSettings {
  return {
    timezone: settings.timezone,
    currency: settings.currency,
    electricityPricePerKwh: n(settings.electricityPricePerKwh),
    carKmPerLitre: n(settings.carKmPerLitre),
    scooterKwhPerKm: n(settings.scooterKwhPerKm)
  };
}

export function serializeProfile(profile: {
  id: string;
  name: string;
  kind: "SCOOTER" | "CAR" | "BIKE" | "OTHER";
  kmRate: DecimalLike;
  isActive: boolean;
}): TransportProfile {
  return {
    id: profile.id,
    name: profile.name,
    kind: profile.kind,
    kmRate: n(profile.kmRate),
    isActive: profile.isActive
  };
}

export function serializeTrip(trip: {
  id: string;
  profileId: string;
  tripDate: Date;
  description: string;
  distanceKm: DecimalLike;
  fuelPricePerLitre: DecimalLike;
  earningsAmount: DecimalLike;
  electricityCost: DecimalLike;
  equivalentFuelLitres: DecimalLike;
  equivalentFuelCost: DecimalLike;
  netProfit: DecimalLike;
}): Trip {
  return {
    id: trip.id,
    profileId: trip.profileId,
    tripDate: trip.tripDate.toISOString(),
    description: trip.description,
    distanceKm: n(trip.distanceKm),
    fuelPricePerLitre: n(trip.fuelPricePerLitre),
    earningsAmount: n(trip.earningsAmount),
    electricityCost: n(trip.electricityCost),
    equivalentFuelLitres: n(trip.equivalentFuelLitres),
    equivalentFuelCost: n(trip.equivalentFuelCost),
    netProfit: n(trip.netProfit)
  };
}
