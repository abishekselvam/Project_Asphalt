import { z } from "zod";

export const registerSchema = z.object({
  email: z.string().email(),
  password: z.string().min(8).max(64)
});

export const settingsSchema = z.object({
  timezone: z.string().min(2),
  currency: z.string().min(3).max(3).transform((v) => v.toUpperCase()),
  electricityPricePerKwh: z.number().min(0),
  carKmPerLitre: z.number().positive(),
  scooterKwhPerKm: z.number().positive()
});

export const profileSchema = z.object({
  name: z.string().min(1).max(64),
  kind: z.enum(["SCOOTER", "CAR", "BIKE", "OTHER"]),
  kmRate: z.number().min(0),
  isActive: z.boolean().optional()
});

export const tripSchema = z.object({
  profileId: z.string().min(1),
  tripDate: z.string().datetime(),
  description: z.string().min(1).max(240),
  distanceKm: z.number().min(0),
  fuelPricePerLitre: z.number().min(0),
  earningsAmount: z.number().min(0).optional()
});
