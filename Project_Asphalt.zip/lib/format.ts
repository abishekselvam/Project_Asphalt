export function currency(value: number, code: string) {
  return new Intl.NumberFormat("en-AU", {
    style: "currency",
    currency: code,
    maximumFractionDigits: 2
  }).format(value);
}
