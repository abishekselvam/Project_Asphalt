import { describe, expect, it } from "vitest";
import { calculateTripMetrics } from "@/lib/calc";

describe("calculateTripMetrics", () => {
  it("computes expected values", () => {
    const result = calculateTripMetrics({
      distanceKm: 30,
      fuelPricePerLitre: 2,
      carKmPerLitre: 15,
      electricityPricePerKwh: 0.3,
      scooterKwhPerKm: 0.04
    });

    expect(result.equivalentFuelLitres).toBe(2);
    expect(result.equivalentFuelCost).toBe(4);
    expect(result.electricityCost).toBe(0.36);
    expect(result.netProfit).toBe(3.64);
    expect(result.costSavedVsCar).toBe(3.64);
  });

  it("handles zero km without NaN", () => {
    const result = calculateTripMetrics({
      distanceKm: 0,
      fuelPricePerLitre: 2.2,
      carKmPerLitre: 14,
      electricityPricePerKwh: 0.3,
      scooterKwhPerKm: 0.03
    });

    expect(result.equivalentFuelLitres).toBe(0);
    expect(result.equivalentFuelCost).toBe(0);
    expect(result.electricityCost).toBe(0);
    expect(result.netProfit).toBe(0);
  });
});
