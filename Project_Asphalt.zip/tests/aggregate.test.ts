import { describe, expect, it } from "vitest";
import { aggregateTrips } from "@/lib/aggregate";

describe("aggregateTrips", () => {
  it("aggregates weekly totals and series", () => {
    const result = aggregateTrips(
      [
        {
          tripDate: new Date("2026-04-01T10:00:00.000Z"),
          netProfit: 20,
          electricityCost: 1,
          equivalentFuelCost: 6,
          distanceKm: 15
        },
        {
          tripDate: new Date("2026-04-03T10:00:00.000Z"),
          netProfit: 30,
          electricityCost: 1.2,
          equivalentFuelCost: 7,
          distanceKm: 20
        }
      ],
      "weekly"
    );

    expect(result.kpi.totalProfit).toBe(50);
    expect(result.kpi.totalElectricityCost).toBe(2.2);
    expect(result.kpi.totalEquivalentFuelCost).toBe(13);
    expect(result.kpi.totalCostSavedVsCar).toBe(10.8);
    expect(result.kpi.totalDistance).toBe(35);
    expect(result.series.length).toBe(1);
  });
});
