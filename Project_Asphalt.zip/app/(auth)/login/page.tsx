"use client";

import { FormEvent, useState } from "react";
import { signIn } from "next-auth/react";
import { useRouter } from "next/navigation";
import Link from "next/link";

export default function LoginPage() {
  const router = useRouter();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);

  async function onSubmit(e: FormEvent) {
    e.preventDefault();
    setLoading(true);
    setError(null);

    const result = await signIn("credentials", {
      email,
      password,
      redirect: false
    });

    setLoading(false);

    if (result?.error) {
      setError("Invalid email or password");
      return;
    }

    router.push("/dashboard");
    router.refresh();
  }

  return (
    <main className="mx-auto flex min-h-screen w-full max-w-md items-center px-4">
      <form onSubmit={onSubmit} className="glass animate-fade-up w-full rounded-2xl p-6">
        <h1 className="text-2xl font-semibold">Welcome back</h1>
        <p className="mt-1 text-sm text-[var(--text-muted)]">Sign in to continue tracking trip profit.</p>

        <label className="mt-6 block text-sm">Email</label>
        <input
          type="email"
          required
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@example.com"
          className="mt-2 w-full rounded-xl border border-white/15 bg-black/20 px-3 py-2"
        />

        <label className="mt-4 block text-sm">Password</label>
        <input
          type="password"
          required
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          placeholder="Enter your password"
          className="mt-2 w-full rounded-xl border border-white/15 bg-black/20 px-3 py-2"
        />

        {error && <p className="mt-3 text-sm text-[var(--accent-coral)]">{error}</p>}

        <button
          disabled={loading}
          className="mt-6 w-full rounded-xl bg-[var(--accent-green)] px-4 py-2 font-semibold text-black disabled:opacity-50"
        >
          {loading ? "Signing in..." : "Sign in"}
        </button>

        <p className="mt-4 text-sm text-[var(--text-muted)]">
          Need an account? <Link href="/register" className="text-[var(--accent-cyan)]">Register</Link>
        </p>
      </form>
    </main>
  );
}
