import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSession } from "@/lib/session";
import { tripSchema } from "@/lib/validation";
import { calculateTripMetrics } from "@/lib/calc";
import { serializeTrip } from "@/lib/serializers";

type Context = {
  params: Promise<{ id: string }>;
};

export async function PATCH(req: NextRequest, context: Context) {
  try {
    const session = await requireSession();
    const { id } = await context.params;
    const body = await req.json();
    const parsed = tripSchema.partial().safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
    }

    const existing = await prisma.trip.findFirst({ where: { id, userId: session.user.id } });
    if (!existing) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    const settings = await prisma.userSettings.findUnique({ where: { userId: session.user.id } });
    if (!settings) {
      return NextResponse.json({ error: "Settings missing" }, { status: 400 });
    }

    const merged = {
      profileId: parsed.data.profileId ?? existing.profileId,
      tripDate: parsed.data.tripDate ?? existing.tripDate.toISOString(),
      description: parsed.data.description ?? existing.description,
      distanceKm: parsed.data.distanceKm ?? existing.distanceKm.toNumber(),
      fuelPricePerLitre: parsed.data.fuelPricePerLitre ?? existing.fuelPricePerLitre.toNumber(),
      earningsAmount: parsed.data.earningsAmount ?? existing.earningsAmount.toNumber()
    };

    const profile = await prisma.transportProfile.findFirst({
      where: { id: merged.profileId, userId: session.user.id, isActive: true }
    });

    if (!profile) {
      return NextResponse.json({ error: "Profile not found" }, { status: 400 });
    }

    const metrics = calculateTripMetrics({
      distanceKm: merged.distanceKm,
      fuelPricePerLitre: merged.fuelPricePerLitre,
      carKmPerLitre: settings.carKmPerLitre.toNumber(),
      electricityPricePerKwh: settings.electricityPricePerKwh.toNumber(),
      scooterKwhPerKm: settings.scooterKwhPerKm.toNumber()
    });

    const trip = await prisma.trip.update({
      where: { id },
      data: {
        profileId: merged.profileId,
        tripDate: new Date(merged.tripDate),
        description: merged.description,
        distanceKm: merged.distanceKm,
        fuelPricePerLitre: merged.fuelPricePerLitre,
        earningsAmount: merged.earningsAmount,
        electricityCost: metrics.electricityCost,
        equivalentFuelLitres: metrics.equivalentFuelLitres,
        equivalentFuelCost: metrics.equivalentFuelCost,
        netProfit: metrics.netProfit
      }
    });

    return NextResponse.json(serializeTrip(trip));
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(_req: NextRequest, context: Context) {
  try {
    const session = await requireSession();
    const { id } = await context.params;
    const existing = await prisma.trip.findFirst({ where: { id, userId: session.user.id } });
    if (!existing) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    await prisma.trip.delete({ where: { id } });
    return new NextResponse(null, { status: 204 });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
