import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSession } from "@/lib/session";
import { tripSchema } from "@/lib/validation";
import { calculateTripMetrics } from "@/lib/calc";
import { serializeTrip } from "@/lib/serializers";

export async function GET(req: NextRequest) {
  try {
    const session = await requireSession();
    const { searchParams } = new URL(req.url);
    const from = searchParams.get("from");
    const to = searchParams.get("to");
    const profileId = searchParams.get("profileId");

    const trips = await prisma.trip.findMany({
      where: {
        userId: session.user.id,
        ...(profileId ? { profileId } : {}),
        ...(from || to
          ? {
              tripDate: {
                ...(from ? { gte: new Date(from) } : {}),
                ...(to ? { lte: new Date(to) } : {})
              }
            }
          : {})
      },
      orderBy: { tripDate: "desc" }
    });

    const latestFuelPrice = trips[0]?.fuelPricePerLitre.toNumber() ?? null;

    return NextResponse.json({
      trips: trips.map(serializeTrip),
      latestFuelPrice
    });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await requireSession();
    const body = await req.json();
    const parsed = tripSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
    }

    const [settings, profile] = await Promise.all([
      prisma.userSettings.findUnique({ where: { userId: session.user.id } }),
      prisma.transportProfile.findFirst({
        where: { id: parsed.data.profileId, userId: session.user.id, isActive: true }
      })
    ]);

    if (!settings || !profile) {
      return NextResponse.json({ error: "Settings/profile missing" }, { status: 400 });
    }

    const metrics = calculateTripMetrics({
      distanceKm: parsed.data.distanceKm,
      fuelPricePerLitre: parsed.data.fuelPricePerLitre,
      carKmPerLitre: settings.carKmPerLitre.toNumber(),
      electricityPricePerKwh: settings.electricityPricePerKwh.toNumber(),
      scooterKwhPerKm: settings.scooterKwhPerKm.toNumber()
    });

    const trip = await prisma.trip.create({
      data: {
        userId: session.user.id,
        profileId: parsed.data.profileId,
        tripDate: new Date(parsed.data.tripDate),
        description: parsed.data.description,
        distanceKm: parsed.data.distanceKm,
        fuelPricePerLitre: parsed.data.fuelPricePerLitre,
        earningsAmount: parsed.data.earningsAmount ?? 0,
        electricityCost: metrics.electricityCost,
        equivalentFuelLitres: metrics.equivalentFuelLitres,
        equivalentFuelCost: metrics.equivalentFuelCost,
        netProfit: metrics.netProfit
      }
    });

    return NextResponse.json(serializeTrip(trip), { status: 201 });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
