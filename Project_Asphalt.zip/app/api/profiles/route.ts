import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSession } from "@/lib/session";
import { profileSchema } from "@/lib/validation";
import { serializeProfile } from "@/lib/serializers";

export async function GET() {
  try {
    const session = await requireSession();
    const profiles = await prisma.transportProfile.findMany({
      where: { userId: session.user.id },
      orderBy: [{ kind: "asc" }, { name: "asc" }]
    });

    return NextResponse.json(profiles.map(serializeProfile));
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function POST(req: NextRequest) {
  try {
    const session = await requireSession();
    const body = await req.json();
    const parsed = profileSchema.safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
    }

    const profile = await prisma.transportProfile.create({
      data: {
        userId: session.user.id,
        name: parsed.data.name,
        kind: parsed.data.kind,
        kmRate: parsed.data.kmRate,
        isActive: parsed.data.isActive ?? true
      }
    });

    return NextResponse.json(serializeProfile(profile), { status: 201 });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
