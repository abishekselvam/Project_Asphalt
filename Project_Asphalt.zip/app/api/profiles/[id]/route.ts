import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSession } from "@/lib/session";
import { profileSchema } from "@/lib/validation";
import { serializeProfile } from "@/lib/serializers";

type Context = {
  params: Promise<{ id: string }>;
};

export async function PATCH(req: NextRequest, context: Context) {
  try {
    const session = await requireSession();
    const { id } = await context.params;
    const body = await req.json();
    const parsed = profileSchema.partial().safeParse(body);
    if (!parsed.success) {
      return NextResponse.json({ error: "Invalid payload" }, { status: 400 });
    }

    const existing = await prisma.transportProfile.findFirst({ where: { id, userId: session.user.id } });
    if (!existing) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    const profile = await prisma.transportProfile.update({
      where: { id },
      data: parsed.data
    });

    return NextResponse.json(serializeProfile(profile));
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}

export async function DELETE(_req: NextRequest, context: Context) {
  try {
    const session = await requireSession();
    const { id } = await context.params;
    const existing = await prisma.transportProfile.findFirst({ where: { id, userId: session.user.id } });
    if (!existing) {
      return NextResponse.json({ error: "Not found" }, { status: 404 });
    }

    const tripCount = await prisma.trip.count({ where: { profileId: id, userId: session.user.id } });
    if (tripCount > 0) {
      await prisma.transportProfile.update({ where: { id }, data: { isActive: false } });
      return NextResponse.json({ archived: true });
    }

    await prisma.transportProfile.delete({ where: { id } });
    return new NextResponse(null, { status: 204 });
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
