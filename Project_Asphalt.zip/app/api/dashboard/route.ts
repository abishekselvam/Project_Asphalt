import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/prisma";
import { requireSession } from "@/lib/session";
import { aggregateTrips, type Range } from "@/lib/aggregate";

export async function GET(req: NextRequest) {
  try {
    const session = await requireSession();
    const { searchParams } = new URL(req.url);
    const range = (searchParams.get("range") || "daily") as Range;
    const from = searchParams.get("from");
    const to = searchParams.get("to");

    const trips = await prisma.trip.findMany({
      where: {
        userId: session.user.id,
        ...(from || to
          ? {
              tripDate: {
                ...(from ? { gte: new Date(from) } : {}),
                ...(to ? { lte: new Date(to) } : {})
              }
            }
          : {})
      },
      orderBy: { tripDate: "asc" }
    });

    const summary = aggregateTrips(
      trips.map((trip) => ({
        tripDate: trip.tripDate,
        netProfit: trip.netProfit.toNumber(),
        electricityCost: trip.electricityCost.toNumber(),
        equivalentFuelCost: trip.equivalentFuelCost.toNumber(),
        distanceKm: trip.distanceKm.toNumber()
      })),
      range
    );

    return NextResponse.json(summary);
  } catch {
    return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  }
}
